package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

//class QueueTest {
//
//	@Test
//	void test() {
//		fail("Not yet implemented");
//	}
//
//}

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class QueueTest {

	/**
	 * Tests for Queue.
	 */
	/**
	 * Task 1: Passing test cases
	 */
	
	private static final String SOME_ITEM = "some-content";
	private Queue<String> q;
	private Queue<String> queue;

	
//	@BeforeEach
	void init() {
		this.q = new Queue<String>();
	}

	
	@BeforeEach
	@DisplayName("is instantiated with new Queue<String>()")
	void initNewQueue(){
		this.queue = new Queue<String>(7); 
	}
	
	//For no param Constructor 
	@Test
	@DisplayName("Verify Queue isEmpty when queue is initialized")
	void isEmptyShouldGiveTrueOnQueueInit() {
			assertTrue(q.isEmpty());
	}
	
	//------------------------------------------------------------------
	@Test
	@DisplayName("Enqueue method that adds string literals items into queue")
	void EnqueueTheQueue1(){
		this.q.enqueue("pens"); 
		this.q.enqueue("pencils"); 
		this.q.enqueue("soap"); 
		this.q.enqueue("vegetable");
		this.q.enqueue("chips");
	//	this.queue.enqueue("shoes");
	//	this.queue.enqueue("books");
		assertEquals("pens pencils soap vegetable chips", this.q.toString()); 
	}
	
	
	@Test
	@DisplayName("Tests dequeue, length, peek, removeAll, and enqueue methods")
	void dequeueLengthPeekRemoveAllEnqueue1() {
		 this.q.enqueue("pens"); 
		 this.q.enqueue("pencils"); 
		 this.q.enqueue("soap"); 
		 this.q.enqueue("vegetable");
		 this.q.enqueue("chips");
		 this.q.enqueue("shoes");
	//	 this.q.enqueue("books");
		 
		 assertEquals("pens", this.q.dequeue());
		 
		 assertEquals("pencils soap vegetable chips shoes ", this.q.toString());
		 assertEquals(5, this.queue.length()); 
		 
		 assertThrows(RuntimeException.class,()->this.queue.enqueue("cake"));
		//Checks that the correct item was dequeued from the queue
		 assertEquals("pens", this.queue.dequeue()); 
		 
		 assertEquals("shoes chips pencils soap", this.queue.toString());
		 
		 assertEquals("pencils", this.q.peek());
		 
		 this.q.removeAll(); //Removes all item in queue
		 assertEquals("", this.q.toString());
	}
		 //------------------------------------------------
		 @Test
			@DisplayName("Verify Queue isEmpty when queue is initialized")
			void isEmptyShouldGiveTrueOnQueueInit1() {
				assertTrue(queue.isEmpty());
			}
		 
		 
		 //-----------------------------------------------------
		 @Test
		@DisplayName("Enqueue methos that adds string literals into the queue")
		void EnqueueTheQueue2(){
			//Stores three(max) item in queue
			this.queue.enqueue("pens"); this.queue.enqueue("pencils"); this.queue.enqueue("soap"); 
			this.queue.enqueue("vegetable"); this.queue.enqueue("chips"); this.queue.enqueue("shoes");
			assertEquals("pens pencils saop vegetable chips shoes ", this.queue.toString()); //Compares values in queues with string literal for equivalence
		 }	
		 
		 
		@Test
		@DisplayName("Tests dequeue, length, peek, removeAll, and enqueue methods")
		void dequeueLengthPeekRemoveAllEnqueue2() {
			this.queue.enqueue("pens"); this.queue.enqueue("pencils"); this.queue.enqueue("soap");
			this.queue.enqueue("vegetable"); this.queue.enqueue("chips"); this.queue.enqueue("shoes");
			
			assertThrows(RuntimeException.class, ()-> this.queue.enqueue("cake")); 
			//Checking dequeue operation
			assertEquals("pens", this.queue.dequeue());
			assertEquals("pencils soap vegetable chips shoes ", this.queue.toString()); 
			assertEquals(5, this.queue.length()); 
			assertEquals("pencils", this.queue.peek()); 
			//Checking removeAll operation
			this.queue.removeAll();
			assertEquals("", this.queue.toString()); 
			//Checking peek operation
			assertThrows(NoSuchElementException.class, ()-> this.queue.peek()); 

		}
	
	/**
	 * Task 2 : Create Test case that *fails* revealing the underlying fault
	 */

	@Test
	@DisplayName("Dequeue should throw an Exception if called on empty queue")
	void FindFaultInDequeue(){
		//No item has been added into the queue yet for user to execute the dequeue feature. 
		//We're calling dequeue on an empty queue, so 
		assertThrows(NoSuchElementException.class, ()->this.q.dequeue()); 
	}

	
}//end QueueTest class